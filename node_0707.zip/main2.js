/**
 * server구동
 */
var http=require('http');
var fs=require('fs');
var url=require('url');
var data;

var app=http.createServer(function(request,response){
	//user가 요청한 url주소를 받음
	var _url=request.url;
	var queryData=url.parse(_url,true).query;
	var title=queryData.id;

	var pathname=url.parse(_url,true).pathname;
	console.log(pathname);
	
	
	//==controller
	//http://localhost:3000/?id=title
	if(pathname=='/'){
		if(title==undefined){
			//main
			title='main';
			content=`
				<h3>naver 뉴스 메인 페이지</h3>
				<p><strong>메인 페이지</strong></p>
				<p>
				네이버 메인 페이지 입니다.
				</p>
			`;
			template=`
				<!DOCTYPE html>
				<html>
				<head>
				<meta charset="UTF-8">
				<title>${title}</title>
				</head>
				<body>
				<ul>
					<li><a href='./'>main</a></li>
					<li><a href='./?id=IT'>IT</a></li>
					<li><a href='./?id=economy'>economy</a></li>
					<li><a href='./?id=politics'>politics</a></li>
				</ul>
				${content}
				</body>
				</html>
				`;
		}
		
		else if(title=='IT'){
			//id
		}
		
		else if(title=='economy'){
			//economy
		}
		
		else if(title=='politics'){
			//politics
		}
	
	}//if title
	
	else{
		response.writeHead(404,{'Content-Type':'text/html;charset=utf-8'});
		response.end('페이지가 없습니다. 다시 입력해 주세요');
		return;
	}
	
	
	response.writeHead(200); //정상적인 페이지 상태
	response.end(template); // 데이타를 보내주는거
});

app.listen(3000);