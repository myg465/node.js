/**
 * http://usejsdoc.org/
 */

var url=require('url');
var _url='http://localhost:3000/?name=홍길동&tel=010-1111-1111&address=서울시 금천구 가산동&id=admin&pw=1234&gender=남';
var queryData=url.parse(_url,true).query;
console.log(queryData.name);
console.log(queryData.tel);
console.log(queryData.address);
console.log(queryData.id);
console.log(queryData.pw);
console.log(queryData.gender);
