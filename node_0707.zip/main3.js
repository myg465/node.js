/**
 * http://usejsdoc.org/
 */

var http=require('http');
var url=require('url');
var fs=require('fs');

var app=http.createServer(function(request,response){
	
	var _url=request.url;
	if(_url=='/'){
		_url='/';
	}
	else if(_url=='/baseball.html'){
		_url='/baseball.html';
	}
	else if(_url=='/football.html'){
		_url='/football.html';
	}
	else if(_url=='/basketball.html'){
		_url='/basketball.html';
	}
	else{
		response.writeHead(404,{'Content-Type':'text/html;charset=utf-8'});
		response.end('페이지가 없습니다.');
		return;
	}
	
	response.writeHead(200);
	response.end(fs.readFileSync(__dirname+_url));
	
});

app.listen(3000);
