/**
 * http://usejsdoc.org/
 */

var url=require('url');
//var _url='http://localhost:3000/index.html/?id=IT&name=홍길동&pass=1234';
var _url='https://search.naver.com/search.naver?sm=top_hty&fbm=1&ie=utf8&query=%EC%B7%A8%EC%97%85';

var queryData=url.parse(_url,true).query;

console.log(queryData.query);
