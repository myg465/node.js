/**
 * http://usejsdoc.org/
 */

console.log('현재 실행한 파일 패스위치: '+__dirname);
console.log('현재 실행한 파일명 : '+__filename);

var _url='/1.html';
console.log('이동 페이지 : '+__dirname + _url);

//배열 선언
var person=['d:/workspace','node_0706','index.html']; 

console.dir('배열 출력 : '+person); 

//객체선언
var obj={name:'소녀시대',age:20};

console.dir(obj); //앞에 문자열을 못붙임

//홍길동,20 / 김유신 30 / 유관순 40/ 김구 50 출력 객체로 만들어서 출력

var member=[{name:'홍길동',age:20},{name:'김유신',age:30},{name:'유관순',age:40},{name:'김구',age:50}]
//객체를 하나씩 생성하고 배열에 넣을수도 있고, 

console.dir(member);

var numbers=[10,20,30,40,50];
console.dir('숫자배열 : '+numbers);
console.time('for_arr');
//for로 출력하기
arr2=[10,20,30,40,50];
for(var i=0;i<arr2.length;i++){
	console.log(i+'번째 데이터 값 : '+arr2[i]);
}
console.timeEnd('for_arr');
console.time('foreach');
//foreach 에서 출력하기 ( 약간 더빠름 )
arr2.forEach(function(item,index){
	console.log(index+'번째 데이터 값 : '+item);
});
console.timeEnd('foreach');









