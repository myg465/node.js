/**
 * http://usejsdoc.org/
 */

var calc=require('./calc'); //외부의 모듈을 불러옴

calc.add(20,10);

console.log('calc객체에서 더하기 함수 호출 : '+calc.add(20,10));


