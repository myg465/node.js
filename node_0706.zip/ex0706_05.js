/**
 * http://usejsdoc.org/
 */

//url='http://localhost:3000/aaa.html?id=admin&pass=1234&name='홍길동'
//호스트네임: 패스네임 : 아이디 :

var url=require('url');
var querystring=require('querystring');
var addressUrl=url.parse('http://localhost:3000/aaa.html?id=admin&pass=1234&name="홍길동"');


console.log('host:'+addressUrl.host);
console.log('호스트네임 : '+addressUrl.hostname);
console.log('패스네임 : '+addressUrl.pathname);
var param=querystring.parse(addressUrl.query);
console.log('아이디 :'+param.id);

var addressQuery=url.parse('http://localhost:3000/aaa.html?id=admin&pass=1234&name="홍길동"',true).query;
console.log('addressQuery : '+addressQuery.name);