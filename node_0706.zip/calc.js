/**
 * http://usejsdoc.org/
 */

var calc={};

function obj1(a,b){
	var result=a+b;
	return result;
}
obj1(10,20);

calc.add=function(a,b){
	return a+b;
};
calc.subtract=function(a,b){
	return a-b;
};
calc.multi=function(a,b){
	return a*b;
};
calc.division=function(a,b){
	return a/b;
};

module.exports=calc; //모듈로 사용할수 있다. 

