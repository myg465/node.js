/**
 * http://usejsdoc.org/
 */

var url=require('url');
var querystring=require('querystring');


var addressUrl=url.parse('http://localhost:3000/1.html?id=css');
//var addressUrl=url.parse('https://search.naver.com/search.naver?sm=top_hty&fbm=1&ie=utf8&query=%EB%89%B4%EC%8A%A4');

console.dir(addressUrl);
console.log(addressUrl.query);
var queryDate=url.parse(addressUrl,true).query;

console.log(queryDate);

var param=querystring.parse(addressUrl.query);
console.log('요청 파라미터 중 id의 값 출력 : '+param.id); //일정 파라미터의 값을 받아옴

//console.log('모듈 객체변환 :');
//console.log('format :');
//var addressStr=url.format(addressUrl);
//console.log('주소 문자열 : '+addressStr);


