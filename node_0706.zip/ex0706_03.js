/**
 * http://usejsdoc.org/
 */

var os=require('os');
var path=require('path'); //패스 모듈 불러오기
var url=require('url'); //url모듈 불러오기

var directories=['users','mike','docs'];
console.dir(directories);
var mergedir=directories.join();//구분자가 쉼표로 들어감
console.log(mergedir);
var filepath=directories.join(path.sep); //구분자가 역슬래시로 들어감
console.log(filepath);

var curpath=path.join('users/mike','notepad.exe');
console.log('패스위치 :'+curpath);

var _url='1.html';
var filepath1=path.join('product/event',_url);
if(_url=='1.html'){
	console.log('호출 url 주소 리턴 :'+filepath1);
}
else if(_url=='2.html'){
	console.log('호출 url 주소 리턴 :'+filepath1);
}

var filename='c:\\users\\mike\\notepad.exe';
path.dirname(filename);
console.log('디렉터리 위치 : '+path.dirname(filename));

path.basename(filename);
console.log('파일이름 : '+path.basename(filename));
path.extname(filename);
console.log('파일 확장자 명 : '+path.extname(filename));

console.dir(url);






















