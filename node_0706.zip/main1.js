/**
 * http://usejsdoc.org/
 */

var http=require('http');//http모듈(서버에 커넥션을 시켜줌)
var fs=require('fs'); //파일시스템 모듈(파일을 읽어와서 실행)
var path=require('path');
var url=require('url');


var app=http.createServer(function(request,response){
	
	//server주소/파일명?id=css
	var _url=request.url; //사용자가 요청한 url
	//localhost:3000/1.html?id=css
	var queryData=url.parse(_url,true).query;
	console.log('[url모듈에서 query 출력]');
	console.log(queryData);
	
	
	if(_url=='/'){
		_url='/index.html';
	}
	else if(_url=='/1.html'){
		_url='/1.html';
	}
	else{
		response.writeHead(404); //응답을 404에러로 한다.
		response.end(); //끝남
		return;
	}
	
	response.writeHead(200);
	response.end(fs.readFileSync(__dirname+_url));
	
});

app.listen(3000); //포트 설정



//var filepath=path.join(__dirname,'1.txt');
//console.log(filepath);

//var txt_1=fs.readFileSync('1.txt','utf-8');// 동기
//console.dir('readFileSync : '+txt_1);
//
//fs.readFile('file1.html','utf-8',function(error,data){ //비동기
//	console.log('readFile : '+data); //콜백함수에서 찍어줌
//});




