/**
 * http://usejsdoc.org/
 */

var fs=require('fs');


//비동기식
fs.readFile('./data/economy','utf-8',function(err,data){
	console.log('비동기식으로 출력');
	console.log(data);
});

console.log('데이터 읽어오기 전에 출력됨.');

console.log('----------------------------------------');

//동기식
var economy_data=fs.readFileSync('./data/IT','utf-8');
console.log('동기식으로 출력');
console.log(economy_data);

console.log('데이터 읽어온 후에 출력됨.');

