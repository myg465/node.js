/**
 * 파일 쓰기
 */

var fs=require('fs');
var title='world2';
var content=`
	<strong>CNN "평양 원로리 지역서 핵탄두 개발 정황 포착"</strong><br>
	북한이 평양 인근 원로리 일대에서 핵탄두를 개발하고 있는 정황을 보여주는
	위성 사진이 포착됐다고 미 CNN 방송이 보도했습니다.

	CNN은 현지 시간 8일 민간 위성 업체 '플래닛 랩스'가 포착한 사진을 입수한 결과 원로리 
	일대에서 감시시설과 주거시설, 지도부 방문 기념비, 지하시설 등이 목격됐다고 보도했습니다.
`;
fs.writeFile(`./data/${title}`,content,function(err){
	if(err){
		console.log('파일 쓰기 에러'+err);
		return;
	}
	fs.readdir('./data',function(err,data){
		data.forEach(function(item,index){
			console.log((index+1)+'번째 리스트 : '+item);
		});
	});
	console.log('파일 쓰기 완료');
})