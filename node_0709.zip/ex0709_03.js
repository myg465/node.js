/**
 * http://usejsdoc.org/
 */

var fs=require('fs');
var content;
fs.readdir('./data',function(err,data){
	
	content=data[0];
	console.log('readdir 내부 출력 : '+content);
	
});
//비동기라서 안나옴(값이 들어가기전에 실행되버림)
console.log('readdir 외부 출력 : '+content);
