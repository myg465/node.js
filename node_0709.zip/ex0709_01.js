/**
 * http://usejsdoc.org/
 */

var url=require('url');
var querystring=require('querystring');


var _url=url.parse('http://localhost:3000/?id=economy&pass=1234');

var queryData=querystring.parse(_url.query);
console.log(queryData.id);
//var queryData=url.parse(_url,true).query;
//console.log(queryData);
//console.log(queryData.id);
//console.log(queryData.pass);
