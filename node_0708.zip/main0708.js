/**
 * server구동
 */
var http=require('http');
var fs=require('fs');
var url=require('url');
var data;
var list='';
//메뉴부분
fs.readdir('./data',function(err,fileList){
	list+='<ul>';
	for(var i=0;i<fileList.length;i++){
		list+=`<li><a href='./?id=${fileList[i]}'>${fileList[i]}</a></li>`;
	}
	list+='</ul>';
});
var app=http.createServer(function(request,response){
	//user가 요청한 url주소를 받음
	var _url=request.url;
	var queryData=url.parse(_url,true).query;
	//http://localhost:3000/?id=IT,id=economy,id=politics...
	var title=queryData.id;

	var pathname=url.parse(_url,true).pathname;
	console.log(pathname);
	
	
//	fileList=`
//		<ul>
//			<li><a href='./?id=IT'>IT</a></li>
//			<li><a href='./?id=economy'>economy</a></li>
//			<li><a href='./?id=politics'>politics</a></li>
//		</ul>
//		`;
	
	//==controller
	//http://localhost:3000/?id=title
	if(pathname=='/'){
		
		if(title==undefined){
			//main
			title='main';
			content=`
				<strong>메인 페이지</strong>
				네이버 메인 페이지 입니다.
			`;
			template=`
				<!DOCTYPE html>
				<html>
					<head>
						<meta charset="UTF-8">
						<title>${title}</title>
					</head>
					<body>
						<h2><a href='./'>main</a></h2>
						${list}
						<h3>${title}</h3>
						<p>
						${content}
						</p>
					</body>
				</html>
				`;
		}
		
		else {
			content=fs.readFileSync(`./data/${title}`,'utf-8');
			template=`
				<!DOCTYPE html>
				<html>
					<head>
						<meta charset="UTF-8">
						<title>${title}</title>
					</head>
					<body>
						<h2><a href='./'>main</a></h2>
						${list}
						<h3>${title}</h3>
						<p>
						${content}
						</p>
					</body>
				</html>
				`;
		}
	
	}//if title
	
	else{
		response.writeHead(404,{'Content-Type':'text/html;charset=utf-8'});
		response.end('페이지가 없습니다. 다시 입력해 주세요');
		return;
	}
	
	
	response.writeHead(200); //정상적인 페이지 상태
	response.end(template); // 데이타를 보내주는거
});

app.listen(3000);
