/**
 * http://usejsdoc.org/
 */

var fs=require('fs');
fs.readdir('./data',function(error,dataList){
	
	for(var i=0;i<dataList.length;i++){
		console.log(`데이터의${i}번째 배열 값 :`+dataList[i]);
		var list=fs.readFileSync(`data/${dataList[i]}`,'utf-8');
		console.log(list);
		
//		fs.readFile(`data/${dataList[i]}`,'utf-8',function(err,data){
//			// 비동기식으로 출력시 문제점-> 제목과 내용이 따로놈
//			console.log(data);
//			
//		});
	}
	
});

