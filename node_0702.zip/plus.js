/**
 * http://usejsdoc.org/
 */

var plus={};
var sum=0; 
plus.plus1=function(a){
	
	for(var i=1;i<=a;i++){
		sum+=i;
	}
	return sum;
	
}
plus.plus2=function(a,b){
	
	for(var i=a;i<=b;i++){
		sum+=i;
	}
	return sum;
}

module.exports=plus;
