/**
 * http://usejsdoc.org/
 */

var calc=require('./calc'); //선언(export로 정의 되있는 거)
var calc2=require('./calc2');

console.log("더하기 : "+calc.add(10,5)); //메소드를 호출가능

//console.log("곱하기 : "+calc.multi(10,5));


console.log('calc2더하기 :'+calc2.add(20, 10));
console.log('calc2빼기 : '+calc2.substract(20,10));
console.log('calc2곱하기 :'+calc2.multi(20,10));
console.log('calc2나누기 :'+calc2.division(20,10));