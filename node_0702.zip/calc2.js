/**
 * http://usejsdoc.org/
 */

var calc ={};

calc.add=function(a,b){
	return a+b;
}
calc.substract=function(a,b){
	return a-b;
}
calc.multi=function(a,b){
	return a*b;
}
calc.division=function(a,b){
	return a/b;
}

module.exports=calc; //모듈로 담는다
