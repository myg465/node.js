/**
 * http://usejsdoc.org/
 */

console.log('nodejs실행');

var cls = {name:'css',content:'css의 내용입니다.'} //객체
var num = 1; //숫자
var str = 'server를 구동합니다.'; //문자열

console.log("숫자는 %d",num);
console.log("문자는 %s",str);
console.log("객체는 %j",cls);

console.dir(cls); //객체를 출력시킨다.






