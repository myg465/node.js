/**
 * http://usejsdoc.org/
 */

var compare={};

compare.max=function(a,b){
	if(a>b){
		return a;
	}
	else{
		return b;
	}
	
};

compare.min=function(a,b){
	if(a<b){
		return a;
	}
	else{
		return b;
	}
};

module.exports=compare;