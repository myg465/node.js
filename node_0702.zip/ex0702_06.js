/**
 * http://usejsdoc.org/
 */
//두숫자를 입력해서 큰수를 출력하는 함수를 만들기
//단 모듈을 사용할것 -모듈이름(compare.js);

var compare=require('./compare');

console.log('큰 값 구하기 :' +compare.max(10,30));
console.log('작은 값 구하기 :'+compare.min(10,30));