/**
 * function
 */
var calc={};//객체 변수 선언


calc.add=function(a,b){ //무명함수
	return a+b;
}

calc.multi=function(a,b){
	return a*b;
}

calc.subtract=function(a,b){
	return a-b;
}

calc.division=function(a,b){
	return a/b;
}
console.log(calc.add(10,5));
console.log(calc.subtract(10,5));
console.log(calc.multi(10,5));
console.log(calc.division(10,5));
