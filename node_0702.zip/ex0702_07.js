/**
 * http://usejsdoc.org/
 */

//plus.js -모듈 (1~입력한 숫자까지 총 합을 구하는 함수)
//숫자사이의 총합을 구하는 함수
//plus(10,54)   1~10까지 총합 구하는 함수, 10~54 총합 구하는 함수 
//호출해서 사용하는 로직을 개발하기

const plus=require("./plus");

console.log(plus.plus1(10));
console.log(plus.plus2(10,54));
