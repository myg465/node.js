/**
 * nconf 모듈
 */

var nconf=require('nconf');

nconf.env();

console.dir(nconf.get('OS'));

//console.log('현재 사용하고 있는 OS : %s',nconf.get('OS'));
