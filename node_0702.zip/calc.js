/**
 * http://usejsdoc.org/
 */



exports.add = function(a,b){ //외부에서 호출가능
	return a+b;
}

var multi = function(a,b){
	return a*b;
}
