/**
 * http://usejsdoc.org/
 */

var http=require('http');
var url=require('url');
var fs=require('fs');
var data='';
var list='';

function templateHtml(title,list,content){
	template=`
		<!DOCTYPE html>
		<html>
			<head>
				<meta charset="UTF-8">
				<title>${title}</title>
			</head>
			<body>
				<h2><a href='./'>main</a></h2>
				${list}
				<a href='/create'>메뉴추가</a>
				<h3>${title}</h3>
				<p>
				${content}
				</p>
			</body>
		</html>
		`;
	
	return template;
}
//메뉴리스트
function templateDir(){
	
	fs.readdir('./data',function(err,fileList){
		list='';
		list+='<ul>';
		for(var i=0;i<fileList.length;i++){
			list+=`<li><a href='./?id=${fileList[i]}'>${fileList[i]}</a></li>`;
		}
		list+='</ul>';
	});
	
	return list;
}

//서버 구동
var app=http.createServer(function(request,response){
	
	var url_=request.url;
	var queryData=url.parse(url_,true).query;
	var title=queryData.id;
	var pathname=url.parse(url_,true).pathname;
	//메뉴부분
	templateDir();
	if(pathname=='/'){
		if(title==undefined){
		title='main';
		content=fs.readFileSync('./index','utf-8');
		template=templateHtml(title,list,content);
		}
		else{
			content=fs.readFileSync(`./data/${title}`,'utf-8');
			template=templateHtml(title,list,content);
		}
	}
	else if(pathname=='/create'){
		title='create';
		content=fs.readFileSync('./form.html','utf-8');
		template=templateHtml(title,list,content);
	}
	else if(pathname=='/create_result'){
		
	}
	else{
		response.writeHead(404,{'Content-Type':'text/html;charset=utf-8'});
		response.end('페이지가 없습니다. 다시 입력해 주세요');
		return;
	}
	response.writeHead(200); //정상적인 페이지 상태
	response.end(template); // 데이타를 보내주는거
	
	
});
app.listen(3000);
