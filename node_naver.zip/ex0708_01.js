/**
 * http://usejsdoc.org/
 */

var fs=require('fs');
fs.readFile('./data/economy','utf-8',function(err,data){
	if(err){
		console.log('파일 읽기 에러'+err);
	}
	
	fs.writeFile('./data/economy2',data,function(err){
		if(err){
			console.log('파일 쓰기 에러'+err);
		}
		console.log('파일 저장 완료');
	});
});